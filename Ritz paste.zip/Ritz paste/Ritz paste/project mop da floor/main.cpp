﻿#include "util.hpp"
#include "cheat/actors/esp.hpp"
#include "cheat/actors/aimbot.hpp"
Overlay::DXOverlay* pOverlay = nullptr;
HWND game_wndw;

int main() {
	system("CLS");

	Sleep(1000);
	Sleep(3000);

	printf("\n [i] Loading dependencies...", 50);

	printf("\n [i] Waiting for FortniteClient-Win64-Shipping.exe", 50);

	game_wndw = FindWindow(0, ("Fortnite  "));
	while (!game_wndw) {
		game_wndw = FindWindow(0, ("Fortnite  "));
		Sleep(400);
	}

	MessageBoxA(NULL, ("Hit OK in lobby"), ("Sativa"), MB_OK);

	driver::initialize();
	process_id = driver::get_pid((L"FortniteClient-Win64-Shipping.exe"));
	driver::set_pid(process_id);
	virtualaddy = driver::get_modulebase((L"FortniteClient-Win64-Shipping.exe"));

	if (debug) {
		printf(("\n [i] Process ID: %d"), process_id);
		printf(("\n [i] Base Address: %llx"), virtualaddy);
	}


	std::cout << ("\n [i] Attaching to FortniteClient-Win64-Shipping.exe");

	std::cout << ("\n [+] Successfully attached");
	Overlay::DXOverlay::GetWindow(FindWindow(0, ("Fortnite  ")));
	auto InitOverlay = pOverlay->InitOverlay();

	std::cout << ("\n [i] Loading dependencies");
	std::thread t(cache_players);
	t.detach();

	std::cout << ("\n [i] Initializing overlay");
	Sleep(1000);
	printf("\n [+] Thank you for choosing Sativa!", 50);
	Sleep(5000);

	::ShowWindow(::GetConsoleWindow(), SW_HIDE);
	switch (InitOverlay)
	{
	case 0: { break; }
	case 1:
	{
		MouseController::Init();
		while (pOverlay->MainLoop(actor_loop)) {
		}
		break;
	}
	}

}