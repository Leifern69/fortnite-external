#include "cache.h"


void cache_players() {
	while (true) {
		
		auto global_temp = std::make_shared<global_s>();

		if (!populate_global_data(global_temp))
			continue;

		tarray<aplayerstate*> players = global_temp->game_state->get_player_array();
		std::vector<std::shared_ptr<player_data>> players_temp;

		for (int i = 0; i < players.Length(); i++) {
			auto player_data_temp = std::make_shared<player_data>();

			if (populate_player_data(global_temp, player_data_temp, players[i]))
				players_temp.push_back(player_data_temp);
		}
		global_temp->players = players_temp;

		std::unique_lock<std::mutex> lock(global->data_mutex);
		global = global_temp;
		lock.unlock();

		std::this_thread::sleep_for(std::chrono::milliseconds(7)); 
	}
}

bool populate_global_data(const std::shared_ptr<global_s>& global_temp) {
	global_temp->world = driver::read<uworld*>(virtualaddy + 0xF1BEEE8);
	debug_ptr((u)global_temp->world, "world");
	if (!(u)global_temp->world) return false;

	global_temp->game_instance = global_temp->world->get_game_instance();
	debug_ptr((u)global_temp->game_instance, "game_instance");
	if (!(u)global_temp->game_instance) return false;

	global_temp->local_player = global_temp->game_instance->get_local_player();
	debug_ptr((u)global_temp->local_player, "local_player");
	if (!(u)global_temp->local_player) return false;

	global_temp->player_controller = global_temp->local_player->get_player_controller();
	debug_ptr((u)global_temp->player_controller, "player_controller");
	if (!(u)global_temp->player_controller) return false;

	global_temp->player_camera_manager = global_temp->player_controller->get_camera_manager();
	debug_ptr((u)global_temp->player_camera_manager, "player_camera_manager");

	global_temp->local_pawn = global_temp->player_controller->get_acknowledged_pawn();
	debug_ptr((u)global_temp->local_pawn, "local_pawn");

	global_temp->local_root_component = global_temp->local_pawn->get_root_component();
	debug_ptr((u)global_temp->local_root_component, "local_root_component");

	global_temp->local_player_state = global_temp->local_pawn->get_player_state();
	debug_ptr((u)global_temp->local_player_state, "local_player_state");

	global_temp->local_player_team_id = global_temp->local_player_state->get_player_id();
	debug_ptr(global_temp->local_player_team_id, "local_player_team_id");



	if ((u)global_temp->local_pawn)
		global_temp->current_weapon = global_temp->local_pawn->get_current_weapon();
	if ((u)global_temp->current_weapon)
		global_temp->weapon_name = global_temp->current_weapon->get_weapon_name();


	global_temp->game_state = global_temp->world->get_game_state();
	debug_ptr((u)global_temp->game_state, "game_state");
	if (!(u)global_temp->game_state) return false;

	return true;
}

bool populate_player_data(const std::shared_ptr<global_s>& global_temp,
	const std::shared_ptr<player_data>& player_data_temp,
	aplayerstate* player_state) {
	

	player_data_temp->player_state = player_state;
	debug_ptr((u)player_data_temp->player_state, "player_state");
	if (!(u)player_data_temp->player_state) return false;

	player_data_temp->player_team_id = player_data_temp->player_state->get_player_id();
	debug_ptr((u)player_data_temp->player_team_id, "player_team_id");

	if (player_data_temp->player_team_id == global_temp->local_player_team_id && player_data_temp->player_team_id != 0) return false;

	player_data_temp->player = player_data_temp->player_state->get_pawn_private();
	debug_ptr((u)player_data_temp->player, "player");
	if (!(u)player_data_temp->player) return false;
	if ((u)global_temp->local_pawn == (u)player_data_temp->player) return false;

	player_data_temp->root_component = player_data_temp->player->get_root_component();
	debug_ptr((u)player_data_temp->root_component, "root_component");
	if (!(u)player_data_temp->root_component) return false;

	player_data_temp->relative_location = player_data_temp->root_component->get_relative_location();
	debug_3d(player_data_temp->relative_location, "relative_location");

	player_data_temp->player_distance = camera_postion.location.distance(player_data_temp->relative_location) / 100;
	debug_1d(player_data_temp->player_distance, "distance");
	if ((u)global_temp->local_pawn)
		if (player_data_temp->player_distance > max_esp_distance) return false;

	player_data_temp->mesh = player_data_temp->player->get_mesh();
	debug_ptr((u)player_data_temp->mesh, "mesh");
	if (!(u)player_data_temp->mesh) return false;

	return true;
}




