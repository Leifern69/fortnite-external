#pragma once
inline static const char* CurrentWeaponCfg = "Rifle";
inline const char* WeaponCfgs[] = { "Rifle", "Shotgun", "Smg", "Pistol", "Sniper" };

inline int norm_hitbox = 0;
inline const char* norm_Hitboxes[] = { "Head", "Neck", "Chest", "Pelvis" };

inline int CurrentHitbox = 0;
inline const char* Hitboxes[] = { "Head", "Neck", "Chest", "Pelvis" };

inline int CurrentCloseHitbox = 0;
inline const char* CloseHitboxes[] = { "Head", "Neck", "Chest", "Pelvis" };

inline int RifleCurrentHitbox = 1;
inline const char* RifleHitboxes[] = { "Head", "Neck", "Chest", "Pelvis" };
inline int ShotgunCurrentHitbox = 0;
inline const char* ShotgunHitboxes[] = { "Head", "Neck", "Chest", "Pelvis" };
inline int SmgCurrentHitbox = 1;
inline const char* SmgHitboxes[] = { "Head", "Neck", "Chest", "Pelvis" };
inline int PistolCurrentHitbox = 1;
inline const char* PistolHitboxes[] = { "Head", "Neck", "Chest", "Pelvis" };
inline int SniperCurrentHitbox = 1;
inline const char* SniperHitboxes[] = { "Head", "Neck", "Chest", "Pelvis" };

static int menu_animation = 0;
static int border_animation = 0;
static int menu_slide = 0;

inline bool menu_open = false;
inline bool debug = false;
inline bool v_sync = true;

inline bool aimbot = true;
inline float smoothing = 15;
inline int target_bone = 0;
inline int fov = 250;
inline bool draw_fov = true;
inline int max_aimbot_distance = 250;
inline bool triggerbot = true;
inline bool targetline = false;
inline bool weaponconfigs = false;
inline int aimdelay = 0;

inline int norm_fov = 8;
inline int norm_smooth = 19;

inline int smoothness1 = 13;
inline int smoothness2 = 6;
inline int smoothness3 = 11;
inline int smoothness4 = 12;
inline int smoothness5 = 4;

inline int fov1 = 13;
inline int fov2 = 9;
inline int fov3 = 10;
inline int fov4 = 11;
inline int fov5 = 8;

inline int real_hitbox;
inline int real_smooth;

inline bool CRFOV = false;
inline int distance69 = 10;
inline bool close_distance = false;
inline int close_fov = 13;
inline float close_smooth = 4;
inline int close_hitbox = 0;
inline int AimSpeedCloseRange = 14;

inline bool esp = true;
inline bool box_esp = true;
inline bool box_outline = true;
inline bool box_round = false;
inline bool line = true;
inline bool skeleton = true;
inline bool draw_username = false;
inline bool draw_platform = false;
inline bool draw_distance = true;
inline bool draw_held_weapon = false;
inline int box_type = 0;
inline float box_thickness = 1;
inline float box_outline_thickness = 2.5;
inline int max_esp_distance = 250;

inline bool draw_crosshair = true;
inline bool draw_fps = false;

inline float Resx = 1920;
inline float Resy = 1080;